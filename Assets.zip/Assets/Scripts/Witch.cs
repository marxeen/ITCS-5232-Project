﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Witch : MonoBehaviour
{
    public float minDist = 2.0f;
    float distance;
    public Transform player;
    public GameObject bullet;
    public Animator anim;

    float moveSpeed = 3f;
    bool close = false;
    float timer = 0f;
    GameObject instBullet;
    Rigidbody brb;
    
    float stopDist = 2;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(player){
            distance = Vector3.Distance(player.position, transform.position);
        }

        if(distance <= minDist){
            close = true;
            
        }
        if (distance > stopDist){
            close = false;
            anim.SetBool("attack", false);
        }

        //Debug.Log(distance);
        //Debug.Log(stopDist);
        if(close == true){
            
            
            Vector3 pos = (transform.forward *.1f) + transform.position;
            if(timer <= 0.0f){
                anim.SetBool("attack", true);
                instBullet = Instantiate(bullet,pos,Quaternion.identity) as GameObject;
                instBullet.transform.forward = transform.forward;
                brb = instBullet.GetComponent<Rigidbody>();
                timer = 1f;
            }
            else{
                timer -= Time.deltaTime;
            }
            //Debug.Log(timer);
            if(instBullet != null){
                Vector3 attack = (player.position-pos).normalized;
                brb.AddForce(attack * moveSpeed);
            }

            stopDist = distance;
        }

        
    }

    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.CompareTag("projectile")){
            playAnimation();
            Destroy(this.gameObject);
        }
    }

    private void playAnimation(){

    }
}
