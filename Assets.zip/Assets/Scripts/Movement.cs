using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public Rigidbody rb;

    public float moveSpeed = 30f;

    private Vector3 moveInput;

    public bool isGrounded;
    public Animator anim;
    public GameState manager;
    public GameObject[] hearts;
    int health = 5;
    //private Vector2 mouseInput;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        isGrounded = true;
        health = 5;
    }

    // Update is called once per frame
    void Update()
    {
        float h = 0f;
        float v = 0f;
        
        if( Input.GetKey(KeyCode.W)){
            v += .1f;
            transform.Translate(new Vector3(0, 0,v * Time.deltaTime * moveSpeed ));
           if(isGrounded == false){
                anim.SetBool("jump", true);
                anim.SetBool("right", false);
                anim.SetBool("left", false);
                anim.SetBool("isWalking", false);
            } 
            else if(Input.GetKey(KeyCode.A)){
                anim.SetBool("right", true);
                anim.SetBool("left", false);
                anim.SetBool("isWalking", false);
                anim.SetBool("isIdle", false);
            } 
            else if (Input.GetKey(KeyCode.D)){
                anim.SetBool("right", false);
                anim.SetBool("left", true);
                anim.SetBool("isWalking", false);
                anim.SetBool("isIdle", false);

            }
            else{
                anim.SetBool("isWalking", true);
                anim.SetBool("isIdle", false);
                anim.SetBool("right", false);
                anim.SetBool("left", false);
            }
            //rb.velocity = transform.forward *v* Time.deltaTime * moveSpeed;
            //Debug.Log("Player moving by " +transform.forward.x + ", " + transform.forward.z);
        }
        if(!Input.anyKey){
                anim.SetBool("isIdle", true);
                anim.SetBool("isWalking", false);
                anim.SetBool("left", false);
                anim.SetBool("right", false);
        }
        else if(isGrounded == false){
                anim.SetBool("jump", true);
                
                anim.SetBool("isIdle", false);
            }
        if( Input.GetKey(KeyCode.S)){
            v -= .1f;
            transform.Translate(new Vector3(0, 0,v * Time.deltaTime * moveSpeed ));
            //rb.velocity = transform.forward *v* Time.deltaTime * moveSpeed;
            //Debug.Log("Player moving by " +transform.forward.x + ", " + transform.forward.z);
            anim.SetBool("isWalking", true);
            anim.SetBool("isIdle", false);
        }
        if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D) ){
            if(Input.GetKey(KeyCode.A)){
                anim.SetBool("right", true);
                anim.SetBool("left", false);
                anim.SetBool("isWalking", false);
                anim.SetBool("isIdle", false);

            }
            else if(isGrounded == false){
                anim.SetBool("jump", true);
                anim.SetBool("right", false);
                anim.SetBool("left", false);
            } 
            else if (Input.GetKey(KeyCode.D)){
                anim.SetBool("right", false);
                anim.SetBool("left", true);
                anim.SetBool("isWalking", false);
                anim.SetBool("isIdle", false);

            }
            

            transform.Translate( Input.GetAxis("Horizontal") *.1f* Time.deltaTime * moveSpeed ,0,0);
            
        }
        
        if(Input.GetKeyDown(KeyCode.Space)){
            h += 1;
            float jump = 3f;
            
            if(isGrounded == true){
                anim.SetBool("jump", true);
                anim.SetBool("right", false);
                anim.SetBool("left", false);
                anim.SetBool("isWalking", false);
                rb.AddForce(Vector3.up * jump, ForceMode.Impulse) ;
                isGrounded = false;
            }
                
        }

        
        moveInput = new Vector3( v, rb.velocity.y, Input.GetAxis("Horizontal"));

        Vector3 moveHorizontal = transform.forward * moveInput.x;

        Vector3 moveVertical = transform.right * moveInput.z;
        
        //rb.velocity = (moveHorizontal + moveVertical) * moveSpeed;

        transform.Rotate(0, Input.GetAxis("Horizontal") *90f* Time.deltaTime * 1.2f, 0);
    }

    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.CompareTag("obstacle")){
            
            Debug.Log(transform.eulerAngles.y);
            
                health -= 1;
                if(health >= 0)
                    hearts[health].SetActive(false);
                transform.Translate(new Vector3( 0, 0,-.1f)  );
            
            
           
            //transform.Translate(transform.forward  -.5f);
        }
        else if(other.gameObject.CompareTag("enemy")){
            health -= 1;
            if(health >= 0)
                hearts[health].SetActive(false);
        }

        if(health <= 0){
            //Destroy(this.gameObject);
            Time.timeScale = 0;
            manager.gameOver();
            this.enabled = false;
        }

        if(other.gameObject.CompareTag("ground")){
            isGrounded = true;
            anim.SetBool("jump", false);
        }
    }

    public void GainHealth(){
        if(health < 5){
            hearts[health].SetActive(true);
            health += 1;
        }
            
    }
    
    public int getHealth(){
        return health;
    }
}
