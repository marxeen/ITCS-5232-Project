﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnicornCage : MonoBehaviour
{
    public Movement player;
    public Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision other) {
        
        if(other.gameObject.CompareTag("projectile")){
                playAnimation();
                player.GainHealth();
                anim.SetBool("free", true);
                Destroy(this.gameObject, .6f);
        }
    }

    void playAnimation(){

    } 
}
