﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class demonCat : MonoBehaviour
{
    public float minDist = 2.0f;
    float distance;

    public Transform player;
    public Rigidbody rb;
    public Animator anim;
    
    float moveSpeed = 3f;
    bool close = false;
    float m = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(player){
            distance = Vector3.Distance(player.position, transform.position);
        }

        if(distance <= minDist){
            close = true;
            anim.SetBool("attack", close);
            anim.SetBool("idle", false);
            //Debug.Log("Player is in range!");
            m += .01f;

            //rb.velocity = transform.forward * ;
            transform.Translate(new Vector3(0, 0,m * moveSpeed * Time.deltaTime ));
        }
        else{
            anim.SetBool("idle", true);
            anim.SetBool("attack", false);
        }

        
            
        
    }

    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.CompareTag("projectile")){
            playAnimation();
            Destroy(this.gameObject);
        }
        if(other.gameObject.CompareTag("Player")){
            Destroy(this.gameObject);
        }
    }

    private void playAnimation(){

    }
}
