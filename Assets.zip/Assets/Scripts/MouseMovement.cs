﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseMovement : MonoBehaviour
{
    Vector3 pos;
    Vector3  target;
    Vector3 direction;
    Vector3 spread;

    public float offset = 3f;
    public GameObject bullet;
    public Transform player;
    public float speed = 100f;

    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        pos = Input.mousePosition;
        pos.z = offset;
        pos.z += Camera.main.nearClipPlane;
        transform.position = Camera.main.ScreenToWorldPoint(pos);
        
        shoot();

    }
    GameObject instBullet;
    Rigidbody brb;
    void shoot(){
        
        if(Input.GetMouseButtonDown(0)){
            //Debug.Log("I'm shooting");
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            
            if(Physics.Raycast(ray, out hit)){
                if(hit.transform.name != player.transform.name)
                target = hit.point;
                //Debug.Log(hit.transform.name);
                
            }
            else{
                target = ray.GetPoint(2);
            }
            //Debug.Log(target);
            direction = transform.position;
            
             instBullet = Instantiate(bullet,direction,Quaternion.identity) as GameObject;
             instBullet.transform.forward = transform.position.normalized;
             brb = instBullet.GetComponent<Rigidbody>();
            instBullet.transform.forward = transform.forward;
            //brb.AddForce(Vector3.forward * speed * Time.deltaTime);
            
        }
        
        if(instBullet != null){
            Vector3 v = (target-direction).normalized;
            
            brb.velocity =(v * speed * Time.deltaTime);
            //Debug.Log(brb.velocity);
        }
        
    }

}
