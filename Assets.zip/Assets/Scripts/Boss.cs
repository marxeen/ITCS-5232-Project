﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System;
public class Boss : MonoBehaviour
{
    public int health;
    public float minDist = .4f;
    
    public Transform player;
    public GameObject bullet;
    public GameObject rock;
    public Animator anim;
    GameObject instBullet;
    
    Rigidbody brb;

    float distance;
    float m = 0;
    float h = 0;
    float timer = 0f;
    float moveSpeed = 3f;
    bool right = true;
    int count = 0;
    Vector3 oldPos;
    Vector3 pos;
    // Start is called before the first frame update
    void Start()
    {
        health = 10;
        oldPos = player.position;
    }

    // Update is called once per frame
    void Update()
    {
        
        
        pos = (transform.forward *.1f) + transform.position;
        //Debug.Log("Current " + player.position.x);
        //Debug.Log( "Previous " + oldPos.x);
        if(player){
            distance = Vector3.Distance(player.position, transform.position);
        }

        if(distance < minDist){
            
            Debug.Log("Player is in range!");
            m -= .01f;
            /*if( h >= .055)
                right = true;
            else if (h <= -.07)
                right = false;
            if(right == true)
                h -= .01f;
            else
                h += .01f;
            */
              h += 0; 
            transform.Translate(new Vector3(h, 0,m * moveSpeed * Time.deltaTime ));
        }

        if(timer <= 0){
                anim.SetBool("energy", true);
                anim.SetBool("idle", false);
                Invoke("energyAttack", .05f);
                
                timer = .8f;
        }
        else{
            if(timer <= .1f && timer >= .09f ){
                if(player.position.x == oldPos.x){
                    anim.SetBool("rock", true);
                    anim.SetBool("idle", false);

                    Invoke("rockAttack", .3f);
                    
                }
                else if(player.position.x >= (oldPos.x -.0004f) && player.position.x <= (oldPos.x +.0004f)){
                    anim.SetBool("rock", true);
                    anim.SetBool("idle", false);

                    Invoke("rockAttack", 1f);
                }
            }
            
            timer -= Time.deltaTime;
        }
        
        if(instBullet != null){
                Vector3 attack = (player.position-pos).normalized;
                
                brb.AddForce(attack * moveSpeed);
                
            }

        oldPos = player.position;
    }
    void endEnergy(){
        anim.SetBool("idle", true);
        anim.SetBool("energy", false);
        
    }
    void energyAttack(){
        instBullet = Instantiate(bullet,pos,Quaternion.identity) as GameObject;
                instBullet.transform.forward = transform.forward;
                brb = instBullet.GetComponent<Rigidbody>();
                Invoke("endEnergy", .2f);
    }
    void endRock(){
        anim.SetBool("idle", true);
        anim.SetBool("rock", false);
    }
    void rockAttack(){
        pos = player.position + new Vector3(0,.3f,.4f);
                    instBullet = Instantiate(rock,pos,Quaternion.identity) as GameObject;
                    instBullet.transform.forward = transform.forward * 1.5f;
                    instBullet.transform.rotation = Quaternion.Euler(0,90,0);
                    brb = instBullet.GetComponent<Rigidbody>();
                    Invoke("endRock", .05f);
    }

    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.CompareTag("projectile")){
            health -= 1;
            Debug.Log("Boss is hit! ");
            if(health <= 0){
                Destroy(this.gameObject);
            }
        }

        if(other.gameObject.CompareTag("ground")){
            count++;
            Debug.Log(right);
            if(count == 0){
                right = true;
            }
            else{
                right = false;
                count = 0;
            }
        }
    }

    private void OnDestroy() {
        if(health <= 0)
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    
}
