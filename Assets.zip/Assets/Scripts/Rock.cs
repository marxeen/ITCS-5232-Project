﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rock : MonoBehaviour
{
    int health = 3;
    public Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision other) {
        if(other.gameObject.CompareTag("Player")){
            Debug.Log("Player takes 1 damage!");
            
        }
        if(other.gameObject.CompareTag("projectile")){
            health -= 1;
            Debug.Log("Rock is hit! ");
            if(health == 3){
                anim.SetInteger("hit", 0);
            }
            else if(health == 2){
                anim.SetInteger("hit", 1);
            }
            else if(health == 1){
               anim.SetInteger("hit", 2); 
            }
            
            if(health <= 0){
                anim.SetInteger("hit", 3);
                Destroy(this.gameObject, .28f);
            }
        }
    } 
}
